package com.pei.test.controller;

import com.google.gson.Gson;
import com.pei.test.tool.jumpPage;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@EnableTransactionManagement
@RestController
public class indexController {
    @RequestMapping("/index")
    public String aboutBack() {
        return getJumpPage("user", "0", "SUCCESS", "../setting.html");
    }

    @RequestMapping("/indexInspect")
    public String indexInspect() {
        return getJumpPage("user", "0", "SUCCESS", "./templates/inspect.html");
    }

    @RequestMapping("/indexNursing")
    public String indexNursing() {
        return getJumpPage("user", "0", "SUCCESS", "./templates/nursing.html");
    }

    @RequestMapping("/indexSetting")
    public String indexSetting() {
        return getJumpPage("user", "0", "SUCCESS", "./templates/setting.html");
    }


    private String getJumpPage(String user, String code, String msg, String url) {
        jumpPage page = new jumpPage(user, code, msg, url);
        Gson gs = new Gson();
        return gs.toJson(page);
    }
}
