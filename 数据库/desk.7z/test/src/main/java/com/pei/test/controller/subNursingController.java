package com.pei.test.controller;

import com.google.gson.Gson;
import com.pei.test.tool.jumpPage;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@EnableTransactionManagement
@RestController
public class subNursingController {
    @RequestMapping("/subNursingBack")
    public String subNursingBack(@RequestBody String params) {
        System.out.println(params + "           ");
        return getJumpPage("user", "0", params, "./nursing.html");
    }

    @RequestMapping("/subNursingOrder")
    public String subNursingOrder() {
        return getJumpPage("user", "0", "SUCCESS", "./nursing/order.html");
    }

    @RequestMapping("/subNursingInfusion")
    public String subNursingInfusion() {
        return getJumpPage("user", "0", "SUCCESS", "./nursing/infusion.html");
    }

    @RequestMapping("/subNursingTest")
    public String subNursingTest() {
        return getJumpPage("user", "0", "SUCCESS", "./nursing/test.html");
    }

    @RequestMapping("/subNursingTestResult")
    public String subNursingTestResult() {
        return getJumpPage("user", "0", "SUCCESS", "./nursing/testResult.html");
    }

    @RequestMapping("/subNursingCare")
    public String subNursingCare() {
        return getJumpPage("user", "0", "SUCCESS", "./nursing/care.html");
    }

    private String getJumpPage(String user, String code, String msg, String url) {
        jumpPage page = new jumpPage(user, code, msg, url);
        Gson gs = new Gson();
        return gs.toJson(page);
    }
}
