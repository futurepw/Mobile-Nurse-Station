package com.pei.test.server.functionImpl;

public class singsService {
}
