package com.pei.test.controller;

import com.google.gson.Gson;
import com.pei.test.entity.Care;
import com.pei.test.tool.jumpPage;
import com.pei.test.tool.toJson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.pei.test.server.functionImpl.careService;
@EnableTransactionManagement
@RestController
public class careController {
    @Autowired
    careService careService;

    @RequestMapping("/care")
    public String care() {
        Care care = new Care();
        care.setPatientId("P1001");
        return toJson.toResponse("","200","SUCESS",careService.execute(care));
    }

    @RequestMapping("/careBack")
    public String careBack() {
        return getJumpPage("user", "0", "SUCCESS", "../subNursing.html");
    }

    private String getJumpPage(String user, String code, String msg, String url) {
        jumpPage page = new jumpPage(user, code, msg, url);
        Gson gs = new Gson();
        return gs.toJson(page);
    }
}

