package com.pei.test.controller;

import com.pei.test.tool.resourceToString;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@EnableTransactionManagement
@RestController
public class loginController {
    @Value("classpath:json/vue_data_login.json")
    private Resource resource;

    @RequestMapping("/login")
    public String login() {
        return resourceToString.trans(resource);
    }
}
