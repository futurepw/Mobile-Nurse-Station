package com.pei.test.server.entity;

import java.util.Date;

public class chartEntity {
    private String name;
    private String ward_no;
    private Double breathe;
    private Double blood_pressureH;
    private Double blood_pressureL;
    private int pluse;
    private Date date;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getWard_no() {
        return ward_no;
    }

    public void setWard_no(String ward_no) {
        this.ward_no = ward_no;
    }

    public Double getBreathe() {
        return breathe;
    }

    public void setBreathe(Double breathe) {
        this.breathe = breathe;
    }

    public Double getBlood_pressureH() {
        return blood_pressureH;
    }

    public void setBlood_pressureH(Double blood_pressureH) {
        this.blood_pressureH = blood_pressureH;
    }

    public Double getBlood_pressureL() {
        return blood_pressureL;
    }

    public void setBlood_pressureL(Double blood_pressureL) {
        this.blood_pressureL = blood_pressureL;
    }

    public int getPluse() {
        return pluse;
    }

    public void setPluse(int pluse) {
        this.pluse = pluse;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
}
