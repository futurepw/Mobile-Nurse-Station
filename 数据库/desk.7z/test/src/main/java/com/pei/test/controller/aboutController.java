package com.pei.test.controller;

import com.google.gson.Gson;
import com.pei.test.tool.jumpPage;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@EnableTransactionManagement
@RestController
public class aboutController {
    @RequestMapping("/aboutBack")
    public String aboutBack() {
        return getJumpPage("user", "0", "SUCCESS", "../setting.html");
    }

    @RequestMapping("/aboutHelp")
    public String aboutHelp() {
        return getJumpPage("user", "0", "SUCCESS", "./help.html");
    }

    @RequestMapping("/aboutFeedback")
    public String aboutFeedback() {
        return getJumpPage("user", "0", "SUCCESS", "./feedback.html");
    }

    @RequestMapping("/aboutExplain")
    public String aboutExplain() {
        return getJumpPage("user", "0", "SUCCESS", "./explain.html");
    }

    private String getJumpPage(String user, String code, String msg, String url) {
        jumpPage page = new jumpPage(user, code, msg, url);
        Gson gs = new Gson();
        return gs.toJson(page);
    }
}
