/**
 * Date 2018/6/21.
 * Author PeiWei
 */

//获取url
function getUrl() {
    if (true)
        return "http://127.0.0.1:8080";
    else
        return "http://123.206.206.174:8080"
}

//验证电子邮箱
function checkEmail(str) {
    var reg = new RegExp("^[a-z0-9]+([._\\-]*[a-z0-9])*@([a-z0-9]+[-a-z0-9]*[a-z0-9]+.){1,63}[a-z0-9]+$"); //正则表达式
    if (str.value === "") { //输入不能为空
        return -1;
    } else if (!reg.test(obj.value)) { //正则验证不通过，格式不对
        return 0;
    } else { //正则验证通过
        return 1;
    }
}
//验证用户名 用户名正则，4到16位（字母，数字，下划线，减号）
function checkName(str) {
    var reg = new RegExp("^[a-zA-Z0-9_-]{4,16}$"); //正则表达式
    if (str.value === "") { //输入不能为空
        return -1;
    } else if (!reg.test(obj.value)) { //正则验证不通过，格式不对
        return 0;
    } else { //正则验证通过
        return 1;
    }
}

//验证密码 密码强度正则，最少6位，包括至少1个大写字母，1个小写字母，1个数字，1个特殊字符
function checkName(str) {
    var reg = new RegExp("^.*(?=.{6,})(?=.*\d)(?=.*[A-Z])(?=.*[a-z])(?=.*[!@#$%^&*? ]).*$"); //正则表达式
    if (str.value === "") { //输入不能为空
        return -1;
    } else if (!reg.test(obj.value)) { //正则验证不通过，格式不对
        return 0;
    } else { //正则验证通过
        return 1;
    }
}
function first_load() {
    $("#selPaitent").load('subNursing.html');
}
