package com.pei.test.dao;

import com.pei.test.entity.Reportresult;
import com.pei.test.entity.ReportresultKey;

public interface ReportresultMapper {
    int deleteByPrimaryKey(ReportresultKey key);

    int insert(Reportresult record);

    int insertSelective(Reportresult record);

    Reportresult selectByPrimaryKey(ReportresultKey key);

    int updateByPrimaryKeySelective(Reportresult record);

    int updateByPrimaryKey(Reportresult record);
}