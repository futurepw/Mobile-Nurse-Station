package com.pei.test.controller;

import com.google.gson.Gson;
import com.pei.test.tool.jumpPage;
import com.pei.test.tool.resourceToString;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;

@EnableTransactionManagement
@RestController
public class settingController {
    @Value("classpath:json/vue_data_setting.json")
    private Resource resource;

    @RequestMapping("/setting")
    public String setting() {
        return resourceToString.trans(resource);
    }

    @RequestMapping("/settingUserInfo")
    public String settingUserInfo() {
        return getJumpPage("user", "0", "SUCCESS", "./setting/userInfo.html");
    }

    @RequestMapping("/settingChangePw")
    public String settingChangePw() {
        return getJumpPage("user", "0", "SUCCESS", "./setting/changePw.html");
    }

    @RequestMapping("/settingManage")
    public String settingManage() {
        return getJumpPage("user", "0", "SUCCESS", "./setting/manage.html");
    }

    @RequestMapping("/settingAbout")
    public String settingAbout() {
        return getJumpPage("user", "0", "SUCCESS", "./setting/about.html");
    }

    @RequestMapping("/settingLogout")
    public String settingLogout() {
        return "";
    }

    @RequestMapping("/settingInspect")
    public String settingInspect() {
        return getJumpPage("user", "0", "SUCCESS", "./inspect.html");
    }

    @RequestMapping("/settingNursing")
    public String settingNursing() {
        return getJumpPage("user", "0", "SUCCESS", "./nursing.html");
    }

    @RequestMapping("/settingSetting")
    public String settingSetting() {
        return getJumpPage("user", "0", "SUCCESS", "./setting.html");
    }

    @RequestMapping("/settingIndex")
    public String settingIndex() {
        return getJumpPage("user", "0", "SUCCESS", "../index.html");
    }

    private String getJumpPage(String user, String code, String msg, String url) {
        jumpPage page = new jumpPage(user, code, msg, url);
        Gson gs = new Gson();
        return gs.toJson(page);
    }
}
