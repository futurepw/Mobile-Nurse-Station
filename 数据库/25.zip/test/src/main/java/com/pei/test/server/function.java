package com.pei.test.server;

public interface function {
    String execute();//每一个业务都要有一个execute方法，返回字符串类型 结构为 JSON
}
