package com.pei.test.dao;

import com.pei.test.entity.Infusion;

public interface InfusionMapper {
    int deleteByPrimaryKey(String infusionId);

    int insert(Infusion record);

    int insertSelective(Infusion record);

    Infusion selectByPrimaryKey(String infusionId);

    int updateByPrimaryKeySelective(Infusion record);

    int updateByPrimaryKey(Infusion record);
}